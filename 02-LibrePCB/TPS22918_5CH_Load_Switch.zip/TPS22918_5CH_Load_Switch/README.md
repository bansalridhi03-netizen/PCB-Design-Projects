# TPS22918_5CH_Load_Switch

## Description

This is a [LibrePCB](https://librepcb.org) project!
Just edit this file to add a description about it.

## License

No license set.
