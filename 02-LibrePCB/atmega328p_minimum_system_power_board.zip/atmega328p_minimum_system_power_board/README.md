# atmega328p_minimum_system_power_board

## Description

This is a [LibrePCB](https://librepcb.org) project!
Just edit this file to add a description about it.

## License

No license set.
