"DESIGNSPARK_INTERMEDIATE_ASCII" "SnapEDA This work is licensed under a Creative Commons Attribution-ShareAlike 4.0 International License (CC BY-SA) with Design Exception 1.0"
(asciiHeader
  (fileUnits MIL)
)
(library Library
  (padStyleDef "SSX27Y25L1"
    (holeDiam 0)
    (startRange 1)
    (endRange 2)
    (padShape
      (padShapeType Rect)
      (layerNumRef 1)
      (shapeWidth 10.8268)
      (shapeHeight 9.84252)
    )
    (padShape
      (padShapeType Rect)
      (layerNumRef 16)
      (shapeWidth 0)
      (shapeHeight 0)
    )
    (padShape
      (padShapeType Rect)
      (layerNumRef 22)
      (shapeWidth 10.8268)
      (shapeHeight 9.84252)
    )
  )
  (padStyleDef "SSX25Y27L1"
    (holeDiam 0)
    (startRange 1)
    (endRange 2)
    (padShape
      (padShapeType Rect)
      (layerNumRef 1)
      (shapeWidth 9.84252)
      (shapeHeight 10.8268)
    )
    (padShape
      (padShapeType Rect)
      (layerNumRef 16)
      (shapeWidth 0)
      (shapeHeight 0)
    )
    (padShape
      (padShapeType Rect)
      (layerNumRef 22)
      (shapeWidth 9.84252)
      (shapeHeight 10.8268)
    )
  )
  (textStyleDef "H40W40"
    (font
      (fontType Stroke)
      (fontFace "Helvetica")
      (fontHeight 16)
      (strokeWidth 1)
    )
  )
  (textStyleDef "H17W17"
    (font
      (fontType Stroke)
      (fontFace "Helvetica")
      (fontHeight 70)
      (strokeWidth 7)
    )
  )
  (textStyleDef "DEFAULT"
    (font
      (fontType Stroke)
      (fontFace "Helvetica")
      (fontHeight 100)
      (strokeWidth 10)
    )
  )
  (patternDef "XDCR_BMP388"
    (originalName "XDCR_BMP388")
    (multiLayer
      (pad
        (padNum 1)
        (padStyleRef SSX27Y25L1)
        (pt -30.019686, 9.842520)
        (rotation 0)
      )
      (pad
        (padNum 2)
        (padStyleRef SSX27Y25L1)
        (pt -30.019686, -9.842520)
        (rotation 0)
      )
      (pad
        (padNum 3)
        (padStyleRef SSX25Y27L1)
        (pt -19.685040, -30.019686)
        (rotation 0)
      )
      (pad
        (padNum 4)
        (padStyleRef SSX25Y27L1)
        (pt 0.000000, -30.019686)
        (rotation 0)
      )
      (pad
        (padNum 5)
        (padStyleRef SSX25Y27L1)
        (pt 19.685040, -30.019686)
        (rotation 0)
      )
      (pad
        (padNum 6)
        (padStyleRef SSX27Y25L1)
        (pt 30.019686, -9.842520)
        (rotation 0)
      )
      (pad
        (padNum 7)
        (padStyleRef SSX27Y25L1)
        (pt 30.019686, 9.842520)
        (rotation 0)
      )
      (pad
        (padNum 8)
        (padStyleRef SSX25Y27L1)
        (pt 19.685040, 30.019686)
        (rotation 0)
      )
      (pad
        (padNum 9)
        (padStyleRef SSX25Y27L1)
        (pt 0.000000, 30.019686)
        (rotation 0)
      )
      (pad
        (padNum 10)
        (padStyleRef SSX25Y27L1)
        (pt -19.685040, 30.019686)
        (rotation 0)
      )
    )
    (layerContents
      (layerNumRef 39)
      (line (pt 78.7402 -78.7402) (pt -78.7402 -78.7402) (width 1.9685))
    )
    (layerContents
      (layerNumRef 39)
      (line (pt -78.7402 -78.7402) (pt -78.7402 78.7402) (width 1.9685))
    )
    (layerContents
      (layerNumRef 39)
      (line (pt -78.7402 78.7402) (pt 78.7402 78.7402) (width 1.9685))
    )
    (layerContents
      (layerNumRef 39)
      (line (pt 78.7402 78.7402) (pt 78.7402 -78.7402) (width 1.9685))
    )
    (layerContents
      (layerNumRef 30)
      (line (pt 39.3701 -39.3701) (pt -39.3701 -39.3701) (width 5))
    )
    (layerContents
      (layerNumRef 30)
      (line (pt -39.3701 -39.3701) (pt -39.3701 39.3701) (width 5))
    )
    (layerContents
      (layerNumRef 30)
      (line (pt -39.3701 39.3701) (pt 39.3701 39.3701) (width 5))
    )
    (layerContents
      (layerNumRef 30)
      (line (pt 39.3701 39.3701) (pt 39.3701 -39.3701) (width 5))
    )
    (layerContents
      (layerNumRef 30)
      (arc (pt -59.0551 11.811) (radius 3.93701) (startAngle 0) (sweepAngle 360) (width 7.87402))
    )
    (layerContents
      (layerNumRef 18)
      (arc (pt -59.0551 11.811) (radius 3.93701) (startAngle 0) (sweepAngle 360) (width 7.87402))
    )
    (layerContents
      (layerNumRef 18)
      (attr "RefDes" "RefDes"
        (pt -51.2504, 55.1929)
        (rotation 0)
        (textStyleRef "H40W40")
        (isVisible True)
      )
    )
    (layerContents
      (layerNumRef 18)
      (attr "Type" "Type"
        (pt -47.3161, -67.0311)
        (rotation 0)
        (textStyleRef "H40W40")
        (isVisible True)
      )
    )
    (layerContents
      (layerNumRef 20)
      (poly
        (pt -6.88976 -22.6378)
        (pt 6.88976 -22.6378)
        (pt 6.88976 -37.4016)
        (pt -6.88976 -37.4016)
      )
    )
    (layerContents
      (layerNumRef 20)
      (poly
        (pt -6.88976 37.4016)
        (pt 6.88976 37.4016)
        (pt 6.88976 22.6378)
        (pt -6.88976 22.6378)
      )
    )
    (layerContents
      (layerNumRef 20)
      (poly
        (pt -26.5748 37.4016)
        (pt -12.7953 37.4016)
        (pt -12.7953 22.6378)
        (pt -26.5748 22.6378)
      )
    )
    (layerContents
      (layerNumRef 20)
      (poly
        (pt 12.7953 37.4016)
        (pt 26.5748 37.4016)
        (pt 26.5748 22.6378)
        (pt 12.7953 22.6378)
      )
    )
    (layerContents
      (layerNumRef 20)
      (poly
        (pt -26.5748 -22.6378)
        (pt -12.7953 -22.6378)
        (pt -12.7953 -37.4016)
        (pt -26.5748 -37.4016)
      )
    )
    (layerContents
      (layerNumRef 20)
      (poly
        (pt 12.7953 -22.6378)
        (pt 26.5748 -22.6378)
        (pt 26.5748 -37.4016)
        (pt 12.7953 -37.4016)
      )
    )
    (layerContents
      (layerNumRef 20)
      (poly
        (pt 22.6378 16.7323)
        (pt 37.4016 16.7323)
        (pt 37.4016 2.95276)
        (pt 22.6378 2.95276)
      )
    )
    (layerContents
      (layerNumRef 20)
      (poly
        (pt -37.4016 16.7323)
        (pt -22.6378 16.7323)
        (pt -22.6378 2.95276)
        (pt -37.4016 2.95276)
      )
    )
    (layerContents
      (layerNumRef 20)
      (poly
        (pt -37.4016 -2.95276)
        (pt -22.6378 -2.95276)
        (pt -22.6378 -16.7323)
        (pt -37.4016 -16.7323)
      )
    )
    (layerContents
      (layerNumRef 20)
      (poly
        (pt 22.6378 -2.95276)
        (pt 37.4016 -2.95276)
        (pt 37.4016 -16.7323)
        (pt 22.6378 -16.7323)
      )
    )
    (layerContents
      (layerNumRef 39)
      (attr "Type" "DEV" (pt 0, 0) (textStyleRef "DEFAULT") (isVisible False))
    )
    (layerContents
      (layerNumRef 39)
      (attr "PN" "PN" (pt 0, 0) (textStyleRef "DEFAULT") (isVisible False))
    )
    (layerContents
      (layerNumRef 39)
      (attr "DEV" "DEV" (pt 0, 0) (textStyleRef "DEFAULT") (isVisible False))
    )
    (layerContents
      (layerNumRef 39)
      (attr "VAL" "VAL" (pt 0, 0) (textStyleRef "DEFAULT") (isVisible False))
    )
  )
  (symbolDef "BMP388"
    (originalName "BMP388")
    (pin
      (pinNum 1)
      (pt 500 300)
      (rotation 180)
      (pinLength 200 mils)
      (pinDisplay
        (dispPinName True)
      )
      (pinName
        (text
          (pt 240 300) "VDDIO" (rotation 0)
        )
      )
    )
    (pin
      (pinNum 2)
      (pt -500 0)
      (rotation 0)
      (pinLength 200 mils)
      (pinDisplay
        (dispPinName True)
      )
      (pinName
        (text
          (pt -240 0) "SCK" (rotation 0)
        )
      )
    )
    (pin
      (pinNum 3)
      (pt 500 -400)
      (rotation 180)
      (pinLength 200 mils)
      (pinDisplay
        (dispPinName True)
      )
      (pinName
        (text
          (pt 240 -400) "VSS" (rotation 0)
        )
      )
    )
    (pin
      (pinNum 4)
      (pt -500 -100)
      (rotation 0)
      (pinLength 200 mils)
      (pinDisplay
        (dispPinName True)
      )
      (pinName
        (text
          (pt -240 -100) "SDI" (rotation 0)
        )
      )
    )
    (pin
      (pinNum 5)
      (pt -500 -200)
      (rotation 0)
      (pinLength 200 mils)
      (pinDisplay
        (dispPinName True)
      )
      (pinName
        (text
          (pt -240 -200) "SDO" (rotation 0)
        )
      )
    )
    (pin
      (pinNum 6)
      (pt -500 100)
      (rotation 0)
      (pinLength 200 mils)
      (pinDisplay
        (dispPinName True)
      )
      (pinName
        (text
          (pt -240 100) "CSB" (rotation 0)
        )
      )
    )
    (pin
      (pinNum 7)
      (pt 500 0)
      (rotation 180)
      (pinLength 200 mils)
      (pinDisplay
        (dispPinName True)
      )
      (pinName
        (text
          (pt 240 0) "INT" (rotation 0)
        )
      )
    )
    (pin
      (pinNum 8)
      (pt 500 400)
      (rotation 180)
      (pinLength 200 mils)
      (pinDisplay
        (dispPinName True)
      )
      (pinName
        (text
          (pt 240 400) "VDD" (rotation 0)
        )
      )
    )
    (line (pt 300 -500) (pt -300 -500) (width 10))
    (line (pt -300 -500) (pt -300 500) (width 10))
    (line (pt -300 500) (pt 300 500) (width 10))
    (line (pt 300 500) (pt 300 -500) (width 10))
    (attr "RefDes" "RefDes"
      (pt -300.319, 500.638)
      (rotation 0)
      (textStyleRef "H17W17")
      (isVisible True)
    )
    (attr "Type" "Type"
      (pt -300.268, -600.535)
      (rotation 0)
      (textStyleRef "H17W17")
      (isVisible True)
    )
    (attr "Value" "Value" (pt 0, 0) (textStyleRef "DEFAULT") (isVisible False))
  )
  (compDef "BMP388"
    (originalName "BMP388")
    (compHeader
      (numPins 10)
      (numParts 1)
      (refDesPrefix U)
    )
    (compPin "6" (pinName "CSB") (partNum 1) (symPinNum 6) (gateEq 0) (pinEq 0) (pinType Input))
    (compPin "7" (pinName "INT") (partNum 1) (symPinNum 7) (gateEq 0) (pinEq 0) (pinType Output))
    (compPin "2" (pinName "SCK") (partNum 1) (symPinNum 2) (gateEq 0) (pinEq 0) (pinType Input))
    (compPin "4" (pinName "SDI") (partNum 1) (symPinNum 4) (gateEq 0) (pinEq 0) (pinType Bidi))
    (compPin "5" (pinName "SDO") (partNum 1) (symPinNum 5) (gateEq 0) (pinEq 0) (pinType Bidi))
    (compPin "10" (pinName "VDD") (partNum 1) (symPinNum 8) (gateEq 0) (pinEq 0) (pinType Power))
    (compPin "1" (pinName "VDDIO") (partNum 1) (symPinNum 1) (gateEq 0) (pinEq 0) (pinType Power))
    (compPin "3,8,9" (pinName "VSS") (partNum 1) (symPinNum 3) (gateEq 0) (pinEq 0) (pinType Power))
    (attachedSymbol (partNum 1) (altType NORMAL) (symbolName "BMP388"))
    (attachedPattern (patternNum 0) (patternName "XDCR_BMP388") (numPads 10)
      (padPinMap
        (padNum 1) (compPinRef "1")
        (padNum 2) (compPinRef "2")
        (padNum 3) (compPinRef "3")
        (padNum 4) (compPinRef "4")
        (padNum 5) (compPinRef "5")
        (padNum 6) (compPinRef "6")
        (padNum 7) (compPinRef "7")
        (padNum 8) (compPinRef "8")
        (padNum 9) (compPinRef "9")
        (padNum 10) (compPinRef "10")
      )
    )
    (attr "MAXIMUM_PACKAGE_HEIGHT" "0.8 mm")
    (attr "CREATOR" "KARTHIK")
    (attr "STANDARD" "Manufacturer Recommendations")
    (attr "PARTREV" "1.7")
    (attr "MANUFACTURER" "Bosch Sensortec")
    (attr "SNAPEDA_PN" "BMP388")
  )
)